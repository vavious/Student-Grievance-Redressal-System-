# sgrc.github.io
Student grievance redressal system
